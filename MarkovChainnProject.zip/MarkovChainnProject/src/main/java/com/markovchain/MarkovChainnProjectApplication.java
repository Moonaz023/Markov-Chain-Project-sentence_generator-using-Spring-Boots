package com.markovchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarkovChainnProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarkovChainnProjectApplication.class, args);
	}

}
