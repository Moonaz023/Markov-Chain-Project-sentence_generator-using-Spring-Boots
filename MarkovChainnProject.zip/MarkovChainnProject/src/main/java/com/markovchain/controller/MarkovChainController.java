package com.markovchain.controller;


import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

@Controller
public class MarkovChainController {

    @GetMapping("/mark")
    public String index() {
        return "mark"; 
    }

    @GetMapping("/generateSentences")
    public String generateSentences(@RequestParam("start") String start,
                                    @RequestParam("limit") int limit,
                                    Model model) {
        String storyPath = "classpath:/story/";

        List<String> stories = readAllStories(storyPath);
        List<String> cleanedStories = cleanText(stories);
        Map<String, Map<String, Double>> markovModel = makeMarkovModel(cleanedStories);

        Random random = new Random();
        List<String> generatedSentences = generateSentences(markovModel, random, start, limit, 10);

        model.addAttribute("generatedSentences", generatedSentences);
        return "mark"; 
    }

    private List<String> readAllStories(String storyPath) {
        List<String> txt = new ArrayList<>();
        try {
            Resource[] resources = new PathMatchingResourcePatternResolver().getResources(storyPath + "*.txt");
            for (Resource resource : resources) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(resource.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        line = line.strip();
                        if (line.equals("----------")) break;
                        if (!line.isEmpty()) txt.add(line);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return txt;
    }

    private List<String> cleanText(List<String> txtList) {
        List<String> cleanedTxt = new ArrayList<>();
        for (String line : txtList) {
            line = line.toLowerCase();
            line = line.replaceAll("[,.\"'!@#$%^&*(){}?/;`~:<>+=\\\\-]", "");
            String[] tokens = line.split("\\s+");
            for (String word : tokens) {
                if (word.matches("[a-zA-Z]+")) {
                    cleanedTxt.add(word);
                }
            }
        }
        return cleanedTxt;
    }

    private Map<String, Map<String, Double>> makeMarkovModel(List<String> cleanedStories) {
        Map<String, Map<String, Double>> markovModel = new HashMap<>();
        int nGram = 2;
        for (int i = 0; i < cleanedStories.size() - nGram - 1; i++) {
            StringBuilder currState = new StringBuilder();
            StringBuilder nextState = new StringBuilder();
            for (int j = 0; j < nGram; j++) {
                currState.append(cleanedStories.get(i + j)).append(" ");
                nextState.append(cleanedStories.get(i + j + nGram)).append(" ");
            }
            String currStateStr = currState.toString().trim();
            String nextStateStr = nextState.toString().trim();
            markovModel.putIfAbsent(currStateStr, new HashMap<>());
            markovModel.get(currStateStr).merge(nextStateStr, 1.0, Double::sum);
        }

        // calculating transition probabilities
        for (Map.Entry<String, Map<String, Double>> entry : markovModel.entrySet()) {
            double total = entry.getValue().values().stream().mapToDouble(Double::doubleValue).sum();
            Map<String, Double> transitions = entry.getValue();
            for (Map.Entry<String, Double> transitionEntry : transitions.entrySet()) {
                transitionEntry.setValue(transitionEntry.getValue() / total);
            }
        }

        return markovModel;
    }

    private List<String> generateSentences(Map<String, Map<String, Double>> markovModel, Random random,
                                           String start, int limitPerSentence, int numSentences) {
        List<String> generatedSentences = new ArrayList<>();
        for (int i = 0; i < numSentences; i++) {
            String generatedSentence = generateSentence(markovModel, random, start, limitPerSentence);
            generatedSentences.add(generatedSentence);
        }
        return generatedSentences;
    }

//    private String generateSentence(Map<String, Map<String, Double>> markovModel, Random random,
//                                    String start, int limit) {
//        int n = 0;
//        String currState = start;
//        StringBuilder sentence = new StringBuilder(currState + " ");
//        while (n < limit) {
//            Map<String, Double> transitions = markovModel.get(currState);
//            List<String> nextStateList = new ArrayList<>(transitions.keySet());
//            double[] probabilities = nextStateList.stream().mapToDouble(transitions::get).toArray();
//            int index = chooseIndexBasedOnProbability(random, probabilities);
//            currState = nextStateList.get(index);
//            sentence.append(currState).append(" ");
//            n++;
//        }
//        return sentence.toString();
//    }
    private String generateSentence(Map<String, Map<String, Double>> markovModel, Random random,
            String start, int limit) {
int n = 0;
String currState = start;
StringBuilder sentence = new StringBuilder(currState + " ");
while (n < limit) {
Map<String, Double> transitions = markovModel.get(currState);
if (transitions == null || transitions.isEmpty()) {
sentence.append("not-match ");
break; // Exit loop if there's no valid transition
}
List<String> nextStateList = new ArrayList<>(transitions.keySet());
double[] probabilities = nextStateList.stream().mapToDouble(transitions::get).toArray();
int index = chooseIndexBasedOnProbability(random, probabilities);
currState = nextStateList.get(index);
sentence.append(currState).append(" ");
n++;
}
return sentence.toString();
}


    private int chooseIndexBasedOnProbability(Random random, double[] probabilities) {
        double randValue = random.nextDouble();
        double cumulativeProb = 0.0;
        for (int i = 0; i < probabilities.length; i++) {
            cumulativeProb += probabilities[i];
            if (randValue <= cumulativeProb) {
                return i;
            }
        }
        return probabilities.length - 1;
    }
}
